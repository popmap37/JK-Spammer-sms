#by JK Hacker
$ ls
$ cd spammer-grab
$ npm install

คำสั่งใช้
npm run start

คำสั่งใช้งาน
release
